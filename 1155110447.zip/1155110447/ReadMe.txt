Press 'e' to let Alice eat the cake and grow. All chairs will be pushed away
by Alice's growth.

Press 'd' to let Alice drink the bottle of 'drink me' so that she will shrink.
The chairs will be at the normal position.

Press 'r' for calling the eternal return (reset the chair and alice's
positions and height respectively).

Press 'c' to call the Cheshire cat.

